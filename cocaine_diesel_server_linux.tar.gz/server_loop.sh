#! /bin/sh

while true; do
	./headlessupdater
	./server "$@"
	sleep 1
done
